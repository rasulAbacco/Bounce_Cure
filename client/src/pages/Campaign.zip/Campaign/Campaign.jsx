import React from 'react'
import Dashboard from './pages/Dashboard'

const Campaign = () => {
  return (
    <div>
      <Dashboard />
    </div>
  )
}

export default Campaign
