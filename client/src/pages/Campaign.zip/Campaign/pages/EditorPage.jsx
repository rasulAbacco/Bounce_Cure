// import React from 'react';
// import CanvasArea from '../components/Editor/CanvasArea';
// import Toolbox from '../components/Editor/Toolbox';
// import PropertiesPanel from '../components/Editor/PropertiesPanel';
// import Layout  from '../Components/Layout/Layout';

// const EditorPage = () => {
//     return (
//         <Layout>
//             <div className="flex h-screen bg-black">
//                 <Toolbox />
//                 <CanvasArea />
//                 <PropertiesPanel />
//             </div>
//         </Layout>
//     );
// };

// export default EditorPage;

// src/pages/EditorPage.jsx
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import CanvasArea from "../components/Editor/CanvasArea";
import Toolbox from "../components/Editor/Toolbox";
import PropertiesPanel from "../components/Editor/PropertiesPanel";
import { templates } from "../Components/Editor/templates";

const EditorPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();

  // Pick template either from location.state or from templates list
  const template =
    location.state?.template || templates.find((tpl) => tpl.id === id);

  const [elements, setElements] = useState([]);

  // Load default template elements if a template was passed
  useEffect(() => {
    if (template?.elements) {
      setElements(template.elements);
    }
  }, [template]);

  // Handlers for toolbox
  const handleAddElement = (type) => {
    const newElement = {
      id: Date.now(),
      type,
      content:
        type === "heading"
          ? "Heading"
          : type === "paragraph"
          ? "Paragraph text"
          : type === "button"
          ? "Click Me"
          : "",
      src: type === "image" ? "" : null,
      x: 50,
      y: 50,
    };
    setElements((prev) => [...prev, newElement]);
  };

  const handleUploadImage = (src) => {
    const newElement = {
      id: Date.now(),
      type: "image",
      src,
      x: 50,
      y: 50,
    };
    setElements((prev) => [...prev, newElement]);
  };

  const handleUpdate = (updated) => setElements(updated);

  const handleSendTest = () => {
    alert("📨 Test email sent!");
  };

  const handleSaveAndExit = () => {
    // Here you can save to backend before navigating
    alert("✅ Template saved!");
    navigate("/email-campaign");
  };

  if (!template) {
    return (
      <div className="flex h-screen items-center justify-center bg-black text-white">
        <h2 className="text-xl">Template not found</h2>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-black text-white relative">
      {/* Toolbox (left) */}
      <Toolbox
        onAddElement={handleAddElement}
        onUploadImage={handleUploadImage}
        onSelectStockImage={handleUploadImage}
      />

      {/* Canvas Area (center) */}
      <CanvasArea elements={elements} onUpdate={handleUpdate} />

      {/* Properties / Preview Panel (right) */}
      <div className="w-80 bg-gray-900 border-l border-gray-700 p-4 flex flex-col">
        <h2 className="text-lg font-semibold mb-4 text-yellow-400">
          Preview
        </h2>
        <PropertiesPanel elements={elements} />

        <div className="mt-auto flex flex-col gap-3">
          <button
            onClick={handleSendTest}
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white"
          >
            Send Test
          </button>
          <button
            onClick={handleSaveAndExit}
            className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white"
          >
            Save & Exit
          </button>
        </div>
      </div>

      {/* Exit Button (absolute top-right) */}
      <button
        onClick={() => navigate("/email-campaign")}
        className="absolute top-4 right-4 bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-white shadow-lg"
      >
        Exit
      </button>
    </div>
  );
};

export default EditorPage;
