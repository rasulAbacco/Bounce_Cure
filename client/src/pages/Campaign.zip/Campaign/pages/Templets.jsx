import React from "react";
import { useNavigate } from "react-router-dom";
import { templates } from "../Components/Editor/templates";

const TemplatesPage = () => {
  const navigate = useNavigate();

  const handleSelectTemplate = (template) => {
    navigate(`/editor/${template.id}`, { state: { template } });
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold text-yellow-500 mb-6">
        Choose a Template
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((tpl) => (
          <div
            key={tpl.id}
            onClick={() => handleSelectTemplate(tpl)}
            className="bg-gray-900 border border-gray-700 rounded-xl p-6 cursor-pointer hover:shadow-lg hover:border-yellow-500 transition"
          >
            <h2 className="text-lg font-semibold text-white">{tpl.name}</h2>
            <p className="text-sm text-gray-400 mt-2">
              Click to edit this template
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TemplatesPage;



// import React from 'react'

// function Templets() {
//   return (
//     <div className=''>
//       Templets
//       Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus fugit rem provident mollitia debitis ea necessitatibus nemo suscipit, beatae sunt temporibus, quasi cupiditate qui quos itaque error nihil. Rerum, accusamus.
//     </div>
//   )
// }

// export default Templets
