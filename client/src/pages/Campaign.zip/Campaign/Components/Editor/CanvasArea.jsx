// import React from 'react';

// const CanvasArea = () => {
//     return (
//         <div className="flex-1 bg-gray-100 flex items-center justify-center text-black">
//             <p>Design Canvas (Drag & Drop Elements Here)</p>
//         </div>
//     );
// };

// export default CanvasArea;


import React, { useState } from "react";
import { Rnd } from "react-rnd";
import { Eye, X } from "lucide-react"; // Eye for preview, X for close

export default function CanvasArea({ elements, onUpdate }) {
  const [preview, setPreview] = useState(false);

  const updateElement = (id, newProps) => {
    onUpdate(elements.map(el => (el.id === id ? { ...el, ...newProps } : el)));
  };

  return (
    <div className="flex-1 bg-gray-900 p-6 overflow-auto relative">
      {/* Preview Toggle Button */}
      <button
        onClick={() => setPreview(!preview)}
        className="absolute top-4 right-4 bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded flex items-center gap-2 shadow-lg"
      >
        {preview ? (
          <>
            <X size={18} /> Close Preview
          </>
        ) : (
          <>
            <Eye size={18} /> Preview
          </>
        )}
      </button>

      {/* Canvas Area */}
      <div
        className={`bg-white p-6 rounded min-h-[600px] relative transition-all duration-300 ${
          preview ? "w-full" : ""
        }`}
      >
        {elements.map(el => (
          <Rnd
            key={el.id}
            default={{
              x: el.x || 50,
              y: el.y || 50,
              width: el.width || "auto",
              height: "auto",
            }}
            bounds="parent"
            disableDragging={preview} // disable drag in preview mode
            enableResizing={!preview} // disable resize in preview mode
            onDragStop={(e, d) => updateElement(el.id, { x: d.x, y: d.y })}
            onResizeStop={(e, dir, ref, delta, pos) =>
              updateElement(el.id, {
                width: ref.style.width,
                height: ref.style.height,
                ...pos,
              })
            }
          >
            {el.type === "heading" && (
              <h2 className="text-xl font-bold">{el.content || "Heading"}</h2>
            )}
            {el.type === "paragraph" && (
              <p className="text-gray-700">{el.content || "Paragraph text"}</p>
            )}
            {el.type === "button" && (
              <button className="bg-yellow-400 text-black px-4 py-2 rounded">
                {el.content || "Click Me"}
              </button>
            )}
            {el.type === "image" && (
              <img
                src={el.src}
                alt="uploaded"
                className="max-w-full max-h-60 object-contain"
              />
            )}
          </Rnd>
        ))}
      </div>

      {/* Actions (hide in preview) */}
      {!preview && (
        <div className="mt-4 flex gap-4">
          <button className="bg-blue-600 px-4 py-2 rounded text-white">
            Send Test
          </button>
          <button className="bg-green-600 px-4 py-2 rounded text-white">
            Save & Exit
          </button>
        </div>
      )}

      {/* Actions inside preview mode */}
      {preview && (
        <div className="mt-6 flex gap-4 justify-center">
          <button className="bg-blue-600 px-6 py-2 rounded text-white">
            Send
          </button>
          <button className="bg-green-600 px-6 py-2 rounded text-white">
            Save
          </button>
        </div>
      )}
    </div>
  );
}



